package failedRunner;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;

public class FailedCasesRunnerMain {

	public static void main (String args[]) {
		
		TestNG runner = new TestNG();
		List <String> list = new ArrayList<String>();
		list.add("C:\\Users\\agu199\\eclipse-workspace\\RRIMavenProjectNew\\test-output\\testng-failed.xml");
		runner.setTestSuites(list);
		runner.run();
		
	}
}
