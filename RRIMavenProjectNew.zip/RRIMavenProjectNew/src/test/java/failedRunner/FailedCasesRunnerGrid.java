package failedRunner;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;

public class FailedCasesRunnerGrid {

	public static void main (String args[]) {
		
		TestNG runner = new TestNG();
		List <String> list = new ArrayList<String>();
		list.add("C:\\Users\\agu199\\eclipse-workspace\\RRIMavenProjectNew\\test-output\\Grid Suite\\testng-failed.xml");
		runner.setTestSuites(list);
		runner.run();
		
	}
}
