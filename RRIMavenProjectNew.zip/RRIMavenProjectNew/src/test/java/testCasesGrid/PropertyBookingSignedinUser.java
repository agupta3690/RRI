package testCasesGrid;


import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;


import POM.CompleteCheckout;
import POM.FinalizeBooking;
import POM.GuestInformation;
import POM.HomePage;
import POM.PaymentOptions;
import POM.PropertyListing;
import POM.RoomSelect;
import utils.Baseclass;
import utils.GridClass;




public class PropertyBookingSignedinUser extends GridClass{


	@Test ()

	public void property_booking() throws Exception{

	
		driver.get(OR.getProperty("HomePageURL"));


		HomePage homePage = PageFactory.initElements(driver, HomePage.class);
		PropertyListing propertyListing = PageFactory.initElements(driver, PropertyListing.class);
		RoomSelect roomSelect = PageFactory.initElements(driver, RoomSelect.class);
		CompleteCheckout completeCheckout = PageFactory.initElements(driver, CompleteCheckout.class);
		GuestInformation guestInformation = PageFactory.initElements(driver, GuestInformation.class);
		PaymentOptions paymentOptions = PageFactory.initElements(driver, PaymentOptions.class);
		FinalizeBooking finalizeBooking = PageFactory.initElements(driver, FinalizeBooking.class);
		//BookingComplete bookingComplete = PageFactory.initElements(driver, BookingComplete.class);

		try {
			StartReport("Booking with Signed In User");
			homePage.locationSearch("Columbus, OH");
			propertyListing.booking();
			roomSelect.selectRoom();
			completeCheckout.signedinFlow("tmenon", "t123");
			guestInformation.guestInfoSignedin("Special");
			paymentOptions.paymentSignedin();
			finalizeBooking.finalize();
			logger.log(LogStatus.PASS, "The test case Booking with Signed In User ran successfully and stands passed");

		}catch(Exception e)	{
			
			logger.log(LogStatus.FAIL, e.getMessage());

			//Screenshot for failed test.
			
			Baseclass.takeScreenShot(driver, OR.getProperty("BookingSignedinUserFlowFailedTests")+Baseclass.uniqueFileName()+"_signedin_user_failed.png");
		}


	}
	
}




