package research;

import java.util.Scanner;

public class ArrayExample {
	
	public static void main(String args[]) {
		
		Scanner in = new Scanner (System.in);
		int arr[] = new int[5];
		
		System.out.println("Enter the numbers");
		
		for(int i=0; i<arr.length; i++) {
			
			arr[i]=in.nextInt();
			
		}
		
		for (int j=0; j<arr.length; j++) {
		System.out.println(arr[j]);
		
		}
	}

}
