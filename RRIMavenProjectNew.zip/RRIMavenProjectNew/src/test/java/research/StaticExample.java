package research;

public class StaticExample {


	//static variable
	static int a = 10;
	int b = 20;

	public static void main (String args[]){

		StaticExample obj = new StaticExample();
		System.out.println(a);
		System.out.println(obj.b);
	}
}


