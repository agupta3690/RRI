package research;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class CollectionExamples {
	
	public static void main (String args[]) {
		
		List <String> testList = new ArrayList<String>();
		testList.add("Arun");
		testList.add("Gupta");
		testList.add("Ji");
		testList.add("Arun");
		
//		for(int i=0; i<testList.size(); i++) {
//		
//		//System.out.println(testList.get(i));
//		
//		}
//		
//		
//		Iterator <String> listIterator = testList.iterator();
//		while(listIterator.hasNext())
//		{
//		//System.out.println(listIterator.next());
//		}
//		
//		int i=0;
//		while (i<testList.size()) {
//			
//			//System.out.println(testList.get(i));
//			i++;
//			
//			
//		}
		
		
		Set <String> testSet = new HashSet<String>(testList);
		
		for (String setIt:testSet)
			
			System.out.println(setIt);
		
	}

}
