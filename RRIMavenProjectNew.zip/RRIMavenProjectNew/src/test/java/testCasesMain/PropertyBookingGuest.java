package testCasesMain;


import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;


import POM.CompleteCheckout;
import POM.FinalizeBooking;
import POM.GuestInformation;
import POM.HomePage;
import POM.PaymentOptions;
import POM.PropertyListing;
import POM.RoomSelect;
import utils.Baseclass;
import utils.ExcelUtils;




public class PropertyBookingGuest extends Baseclass{
	
	
	@Test(dataProvider = "getData")
	
	public void property_booking(String loc, String fname, String lname, String emailid, String phone, String address1, String address2, String zip, String special, String name, String number, String expiry, String cvv) throws Exception{

		
		driver.get(OR.getProperty("HomePageURL"));


		HomePage homePage = PageFactory.initElements(driver, HomePage.class);
		PropertyListing propertyListing = PageFactory.initElements(driver, PropertyListing.class);
		RoomSelect roomSelect = PageFactory.initElements(driver, RoomSelect.class);
		CompleteCheckout completeCheckout = PageFactory.initElements(driver, CompleteCheckout.class);
		GuestInformation guestInformation = PageFactory.initElements(driver, GuestInformation.class);
		PaymentOptions paymentOptions = PageFactory.initElements(driver, PaymentOptions.class);
		FinalizeBooking finalizeBooking = PageFactory.initElements(driver, FinalizeBooking.class);
		//BookingComplete bookingComplete = PageFactory.initElements(driver, BookingComplete.class);

		
		
		
		
		
		try {
			StartReport("Booking with Guest User");
			
			homePage.locationSearch(loc);
			propertyListing.booking();
			roomSelect.selectRoom();
			completeCheckout.guestFlow();
			guestInformation.guestInfoGuest(fname, lname, emailid, phone, address1, address2, zip, special);
			paymentOptions.paymentGuest(name, number, expiry, cvv);
			finalizeBooking.finalize();
			logger.log(LogStatus.PASS, "The test case Booking with Guest User ran successfully and stands passed");

		}catch(Exception e) {
			
			logger.log(LogStatus.FAIL, e.getMessage());
			
			

			//Screenshot for failed test.

			Baseclass.takeScreenShot(driver, OR.getProperty("BookingGuestUserFlowFailedTests")+Baseclass.uniqueFileName()+"_signedin_failed.png");
		}
		

	}
	
	@DataProvider
	
	 public Object[][] getData() throws Exception{
		 
         Object[][] testObjArray = ExcelUtils.getTableArray(OR.getProperty("TestDataWBook"),OR.getProperty("TestSheetGuest"));
 
         return (testObjArray);
 
		}
}
