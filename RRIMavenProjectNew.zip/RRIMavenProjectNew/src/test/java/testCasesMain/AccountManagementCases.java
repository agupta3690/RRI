package testCasesMain;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import java.io.IOException;

import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import POM.AccountManagement;
import utils.Baseclass;
import utils.ExcelUtils;



public class AccountManagementCases extends Baseclass{


	@Test (dataProvider = "getData")

	public void AccountManagementTest(String fname, String lname, String emailid, String pass, String confirm_pass, String mobile, String phone, String dob) throws IOException {
		
		
		driver.get(OR.getProperty("HomePageURL"));
		

		AccountManagement AccMgmt = PageFactory.initElements(driver, AccountManagement.class);

		try {

			StartReport("Account Management");
			AccMgmt.Join(fname, lname, emailid, pass, confirm_pass, mobile, phone, dob);
			logger.log(LogStatus.PASS, "The test case Account Management ran successfully and stands passed");
		} 
		catch(Exception e) {

			logger.log(LogStatus.FAIL, e.getMessage());
			
			//Screenshot for failed test.

			Baseclass.takeScreenShot(driver, OR.getProperty("AccountManagementFailedTests")+Baseclass.uniqueFileName()+"_acc_mgmt_failed.png");

		}
	}


			@DataProvider

			public Object[][] getData() throws Exception{

				Object[][] testObjArray = ExcelUtils.getTableArray(OR.getProperty("TestDataWBook"),OR.getProperty("TestSheetAccMgmt"));

				return (testObjArray);

			}



		}





