package utils;

import java.io.File;
import java.io.FileInputStream;

import java.io.IOException;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;

import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;

import org.testng.annotations.BeforeClass;

import org.testng.annotations.Parameters;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;



public class Baseclass {
	
	protected ExtentReports extent;
	protected ExtentTest logger;
	public FileInputStream fis;
	public Properties OR;
	public WebDriver driver;
	

	public Baseclass() {

		
		if(OR==null) {

			try {
				OR=new Properties();
				fis=new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\properties\\RRIData.properties");
				OR.load(fis);
			}catch(Exception e) {
				System.out.println(e.getMessage());
			}

		}

	}


	public void movetoElement(WebElement element) {

	}



	public static String uniqueFileName() {

		DateFormat df = new SimpleDateFormat("yyyy-MM-dd_hh-mm-ss");
		df.setTimeZone(TimeZone.getTimeZone("IST"));
		return df.format(new Date());

	}
	
	
	@BeforeClass
	@Parameters("browserName")
	
	
	
	
	public void BrowserInvoke(String browserName){
		
		
		
		if(browserName.equalsIgnoreCase("firefox")){

			System.setProperty("webdriver.gecko.driver", OR.getProperty("GeckoDriver"));
			
			driver=new FirefoxDriver();			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
			driver.manage().window().maximize();
			
			
		    
					
		}else if(browserName.equalsIgnoreCase("chrome")){

			System.setProperty("webdriver.chrome.driver", OR.getProperty("ChromeDriver"));
			driver= new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
			driver.manage().window().maximize();
			
		}
		else if(browserName.equalsIgnoreCase("ie")){

			System.setProperty("webdriver.ie.driver", OR.getProperty("IEDriver"));
			driver= new InternetExplorerDriver();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
			driver.manage().window().maximize();
			
		}
		
	
//			System.setProperty("webdriver.chrome.driver", "C:/chromedriver_win32/chromedriver.exe");
//			driver= new ChromeDriver();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
//			driver.manage().window().maximize();
			
		}
		
				
	
	
	
	
	 @AfterClass
	 	
	public void BrowserClose(){
		
		driver.manage().deleteAllCookies();
		driver.quit();
		
	}



	public static void takeScreenShot(WebDriver driver, String fileWithPath) throws IOException {

		TakesScreenshot scrShot = ((TakesScreenshot)driver);

		File srcFile = scrShot.getScreenshotAs(OutputType.FILE);

		File destFile = new File(fileWithPath);

		FileUtils.copyFile(srcFile, destFile);
	}

	

		
	
	
	public void StartReport(String testName){
		
		
		
		//extent
		//.addSystemInfo("Project Name", "Red Roof Inn")
		//.addSystemInfo("Enviroment", "UAT")
		//.addSystemInfo("User Name", "Arun Gupta");
		
	extent=ExtentManager.getInstance();
	logger=extent.startTest(testName);
	logger.log(LogStatus.INFO, "Starting "+testName+" test");
	}
	
	
	
//	public void getResult(ITestResult result) {
//		if(result.getStatus()==ITestResult.FAILURE){
//			logger.log(LogStatus.FAIL, "The test case which got failed is"+result.getName());
//			logger.log(LogStatus.FAIL, "The test case which got failed is"+result.getThrowable());
//						
//		}else if (result.getStatus()==ITestResult.SKIP){
//			
//			logger.log(LogStatus.SKIP, "The test case which got skipped is"+result.getName());
//			
//			
//		}
//	}
	
	@AfterSuite
	public void endTest(){
		
		
		
		if(extent!=null) {
			
		
		extent.flush();
		extent.close();
		//driver.manage().deleteAllCookies();
		driver.quit();
		
		}
	}
	
	
	@AfterMethod
	
	public void EndReport(){
		
		extent.endTest(logger);
	}
	
	


}




