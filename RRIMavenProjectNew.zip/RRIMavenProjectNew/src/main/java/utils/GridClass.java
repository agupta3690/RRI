package utils;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

public class GridClass extends Baseclass{

	@BeforeClass
	@Parameters("browserName")


	public void BrowserInvoke(String browserName) {

		String Node = "http://10.202.98.162:4444/wd/hub";

		if(browserName.equalsIgnoreCase("firefox")){

			System.setProperty("webdriver.gecko.driver", OR.getProperty("GeckoDriver"));
			
			DesiredCapabilities cap = DesiredCapabilities.firefox();
	 		
	 		cap.setBrowserName("firefox");
	 		cap.setPlatform(Platform.WINDOWS);
	 		
	 		try {
				driver = new RemoteWebDriver(new URL(Node), cap);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
			driver.manage().window().maximize();


		}else if(browserName.equalsIgnoreCase("chrome")){

			System.setProperty("webdriver.chrome.driver", OR.getProperty("ChromeDriver"));
			
DesiredCapabilities cap = DesiredCapabilities.chrome();
	 		
	 		cap.setBrowserName("chrome");
	 		cap.setPlatform(Platform.WINDOWS);
	 		
	 		try {
				driver = new RemoteWebDriver(new URL(Node), cap);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 		
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
			driver.manage().window().maximize();

		}
		
	}




	@AfterClass

	public void BrowserClose(){

		driver.manage().deleteAllCookies();
		driver.quit();

	}
}
