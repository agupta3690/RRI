package POM;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;




public class RoomSelect {

	WebDriver driver;

	@FindBy(xpath = "/html/body/div[1]/div[5]/section/div[2]/div[2]/div[2]/article/section[3]/div[1]/div[2]/div/a[2]")
	@CacheLookup
	WebElement Counter;
	

	@FindBy(xpath = "html/body/div[1]/div[5]/section/div[3]/div[2]/input")
	@CacheLookup
	WebElement Continue_btn;
	
	

	@FindBy(xpath = "html/body/div[1]/div[5]/section/div[2]/div[2]/div[2]/article/section[3]/div[1]/div[2]/div/div/div/input")
	@CacheLookup
	WebElement Count;

	@FindBy(xpath = "html/body/div[1]/div[5]/section/div[2]/div[2]/div[2]/article/section[3]/div[1]/div[2]/div/div/div/input")
	@CacheLookup
	WebElement RoomInput;
	
	@FindBy(xpath = "body/div[1]/div[5]/section[1]/div[2]/div[2]/div[1]/article[1]/section[3]/div[1]/a[1]")
	@CacheLookup
	WebElement SelectRoomBookNow;
	
	


	public RoomSelect(WebDriver driver) {

		this.driver = driver;
	}

	public void selectRoom() throws InterruptedException {
		
	JavascriptExecutor jse = (JavascriptExecutor)driver; 
	jse.executeScript("window.scrollBy(0, 600)", "");

		try{
			do{
				Counter.click();
			}
			while(Integer.parseInt(Count.getAttribute("value"))<=1);
		}
		catch (Exception e){
			
			e.printStackTrace();

		}
		
		Thread.sleep(3000);
		Actions actions = new Actions(driver);
		actions.moveToElement(Continue_btn).click().perform();
		
	
	}
	
	
	public void selectRoomBookNow() {
		
		JavascriptExecutor jse = (JavascriptExecutor)driver; 
		jse.executeScript("window.scrollBy(0, 600)", "");
		SelectRoomBookNow.click();
		
	}
	
}
				
