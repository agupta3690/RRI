package POM;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;




public class PaymentOptions {
	
	WebDriver driver;
	
	@FindBy(className = "new-credit-card-link")
	@CacheLookup
	WebElement Add_new_card_link;
	
	@FindBy(xpath = "//*[@id='input-card-holder-name']")
	@CacheLookup
	WebElement cardholder_name;
	
	@FindBy(id = "input-card-number")
	@CacheLookup
	WebElement card_number;
	
	@FindBy(xpath = "//*[@id=\"input-card-expiry\"]")
	@CacheLookup
	WebElement card_expiry;
	
	@FindBy(xpath = "//*[@id='input-card-cvv']")
	@CacheLookup
	WebElement card_cvv;
	
	@FindBy(xpath = "//input[@id='button-card-submit']")
	@CacheLookup
	WebElement Add_card_btn;
	
	@FindBy(xpath = "//*[@id='checkout-continue-finalize']")
	@CacheLookup
	WebElement checkout_booking_btn;
	
	
	public PaymentOptions(WebDriver driver) {
		this.driver=driver;
		
	}
	
	public void paymentGuest(String name, String number, String expiry, String cvv) throws InterruptedException {

		cardholder_name.sendKeys(name);
		card_number.sendKeys(number);
		card_expiry.sendKeys(expiry);
		card_cvv.sendKeys(cvv);
		checkout_booking_btn.click();
		
		
	}
	
	public void paymentNewUser(String name, String number, String expiry, String cvv) throws InterruptedException {

		
		Add_new_card_link.click();
		cardholder_name.sendKeys(name);
		card_number.sendKeys(number);
		Thread.sleep(2000);
		card_expiry.sendKeys(expiry);
		card_cvv.sendKeys(cvv);
		Thread.sleep(3000);
		Add_card_btn.click();
		Thread.sleep(3000);
		checkout_booking_btn.click();
		
		
	}

	public void paymentSignedin() throws InterruptedException {

		
		checkout_booking_btn.click();
		
		
		
	}
}

	
