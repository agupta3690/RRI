package POM;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;




public class PropertyListing {
	
	WebDriver driver;
	
	@FindBy(xpath = "//a[contains(.,'Load more')]")
	@CacheLookup
	WebElement load_more_btn;

	@FindBy(xpath = "//*[@id=\"list-map-container\"]/section/div[2]/div[1]/div/div[2]/div[1]/article/div/div/footer/div[2]/a")
	@CacheLookup
	WebElement book_now_btn;
	
		
	@FindBy(xpath = "//*[@id='list-map-container']/section/div[2]/div[1]/div/div[2]/div[2]/article/div/div/div[2]/div[3]/div[2]/a")
	@CacheLookup
	WebElement details_link;

	@FindBy(xpath = "//*[@id='list-map-container']/section/div[2]/div[1]/div/div[2]/div[2]/article/div/aside/a")
	@CacheLookup
	WebElement flip_btn;

	@FindBy(xpath = "body/div[1]/section[1]/div[2]/div[1]/div[2]/div[2]/article[1]/div[1]/div[1]/footer[1]/div[2]/a[1]")
	@CacheLookup
	WebElement along_a_route_listing;
	

	public PropertyListing (WebDriver driver) {
		
		this.driver = driver;
	}
	
	public void booking() {
		
		book_now_btn.click();
	}
	
	public void along_a_route_listing() {
		
		JavascriptExecutor jse = (JavascriptExecutor)driver; 
		jse.executeScript("window.scrollBy(500,700)");
		
		Actions actions = new Actions(driver);
		actions.moveToElement(along_a_route_listing).click();

		
	}
	
}
