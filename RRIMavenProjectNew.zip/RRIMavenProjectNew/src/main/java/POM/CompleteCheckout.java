package POM;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;




public class CompleteCheckout {
	
	WebDriver driver;
	
	@FindBy(xpath = "html/body/div[1]/div[2]/section/div/div[1]/form/input")
	@CacheLookup
	WebElement Guest_BookNow_btn;
	
	@FindBy(xpath = "//*[@id=\"checkout-sign-in\"]")
	@CacheLookup
	WebElement SignIn_btn;

	@FindBy(id = "input-email")
	@CacheLookup
	WebElement Username;	

	@FindBy(id = "password")
	@CacheLookup
	WebElement Password;	

	@FindBy(css = "html > body > div > div:nth-of-type(2) > section > div > form > input")
	@CacheLookup
	WebElement Login_btn;	

	@FindBy(css = "html > body > div > div:nth-of-type(2) > section > div > div:nth-of-type(3) > form > input:nth-of-type(3)")
	@CacheLookup
	WebElement SignUp_btn;
	
	
	public CompleteCheckout(WebDriver driver) {
		this.driver = driver;
		
	}
	
	public void guestFlow() {
		
		Guest_BookNow_btn.click();
	}

public void signedinFlow(String username, String password) {
		
	SignIn_btn.click();
	Username.sendKeys(username);
	Password.sendKeys(password);
	Login_btn.click();
	}


public void newUserFlow() {
	
	SignUp_btn.click();
	
}

}
