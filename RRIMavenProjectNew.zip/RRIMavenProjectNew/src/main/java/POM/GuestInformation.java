package POM;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;




public class GuestInformation {

	WebDriver driver;

	@FindBy(xpath = "//*[@id='first-name']")
	@CacheLookup
	WebElement first_name;

	@FindBy(xpath = "//*[@id='last-name']")
	@CacheLookup
	WebElement last_name;

	@FindBy(xpath = "//*[@id='input-email']")
	@CacheLookup
	WebElement email;

	@FindBy(xpath = "//*[@id='input-phone']")
	@CacheLookup
	WebElement phone_number;
	
	@FindBy(xpath = "//*[@id=\"password\"]")
	@CacheLookup
	WebElement password;
	
	@FindBy(xpath = "//*[@id=\"confirm-password\"]")
	@CacheLookup
	WebElement confirm_password;

	@FindBy(xpath = "//*[@id='address1']")
	@CacheLookup
	WebElement address_1;

	@FindBy(xpath = "//*[@id='address2']")
	@CacheLookup
	WebElement address_2;

	@FindBy(xpath = "//*[@id='zipcode']")
	@CacheLookup
	WebElement zipcode;

	@FindBy(xpath = "//*[@id='city']")
	@CacheLookup
	WebElement city;

	@FindBy(xpath = "//*[@id='state']")
	@CacheLookup
	WebElement state;

	@FindBy(xpath = "//*[@id='country']")
	@CacheLookup
	WebElement country;

	@FindBy(xpath = "//*[@id='special-instructions']")
	@CacheLookup
	WebElement special_instructions;

	@FindBy(xpath = "//input[@value='Continue']")
	@CacheLookup
	WebElement checkout_continue_btn;


	public GuestInformation(WebDriver driver) {

		this.driver = driver;
	}

	public void guestInfoGuest(String fname, String lname, String emailid, String phone, String address1, String address2, String zip, String special) throws InterruptedException {

		first_name.sendKeys(fname);
		last_name.sendKeys(lname);
		email.sendKeys(emailid);
		phone_number.sendKeys(phone);
		address_1.sendKeys(address1);
		address_2.sendKeys(address2);
		zipcode.sendKeys(zip);
		special_instructions.sendKeys(special);
		
		Thread.sleep(2000);
		
		checkout_continue_btn.click();
	}
	
	

	public void guestInfoNew(String fname, String lname, String emailid, String pass, String confirm_pass, String phone, String address1, String address2, String zip, String special) throws InterruptedException {

		first_name.sendKeys(fname);
		last_name.sendKeys(lname);
		email.sendKeys(emailid);
		phone_number.sendKeys(phone);
		password.sendKeys(pass);
		confirm_password.sendKeys(confirm_pass);
		address_1.sendKeys(address1);
		address_2.sendKeys(address2);
		zipcode.sendKeys(zip);
		special_instructions.sendKeys(special);
		
		Thread.sleep(2000);
		
		checkout_continue_btn.click();
	}
	
	public void guestInfoSignedin(String special) throws InterruptedException {

		special_instructions.sendKeys(special);
		
		Thread.sleep(2000);
		
		checkout_continue_btn.click();
	}

}
