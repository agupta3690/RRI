package POM;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AccountManagement {

	WebDriver driver;

	@FindBy(xpath = "//*[@id=\"principal-menu\"]/li[8]/a")
	@CacheLookup
	WebElement SigninLink;


	@FindBy(xpath = "//nav/a[1]")
	@CacheLookup
	WebElement SigninTab;

	@FindBy(xpath = "//nav/a[2]")
	@CacheLookup
	WebElement JoinTab;

	@FindBy(id = "input-firstname")
	@CacheLookup
	WebElement JoinFirstName;

	@FindBy(id = "input-lastname")
	@CacheLookup
	WebElement JoinLastName;

	@FindBy(id = "input-email-join")
	@CacheLookup
	WebElement JoinEmail;

	@FindBy(id = "input-password-join")
	@CacheLookup
	WebElement JoinPassword;

	@FindBy(id = "input-password-joinconfirm")
	@CacheLookup
	WebElement JoinConfirmPassword;

	@FindBy(xpath = "//div[@class='module-radio-group-list-item']/label[1]")
	@CacheLookup
	WebElement JoinOptIn1;

	@FindBy(xpath = "//div[@class='module-radio-group-list-item']/label[2]")
	@CacheLookup
	WebElement JoinOptIn2;


	@FindBy(xpath = "//*[@id=\"join\"]/form/fieldset[3]/a/i")
	@CacheLookup
	WebElement ExpandButton;

	@FindBy(id = "mobile-number")
	@CacheLookup
	WebElement JoinMobileNumber;


	@FindBy(id = "phone-number")
	@CacheLookup
	WebElement JoinPhoneNumber;


	@FindBy(id = "birth-date")
	@CacheLookup
	WebElement JoinBirthDate;

	@FindBy(xpath = "//*[@id=\"checkout-continues\" and @value='Join']")
	@CacheLookup
	WebElement JoinContinueBtn;


	@FindBy(xpath = "//div[@class='module-modal-dialog show']/a")
	@CacheLookup
	WebElement ModalCloseIcon;

	@FindBy(id = "add-new-card")
	@CacheLookup
	WebElement AddNewCardLink;

	@FindBy(id = "make-default-card-1")
	@CacheLookup
	WebElement MakeDefaultLink;

	@FindBy(css = "body > div.page-profile > div.inner > section.profile-settings > header > h3 > a")
	@CacheLookup
	WebElement EditProfileLink;

	@FindBy(id = "address1")
	@CacheLookup
	WebElement Address1;

	@FindBy(id = "address2")
	@CacheLookup	
	WebElement Address2;

	@FindBy(id = "address-zip")
	@CacheLookup
	WebElement zip;

	@FindBy(id = "UpperFloor")
	@CacheLookup
	WebElement Preference;


	@FindBy(id = "profile-save-changes")
	@CacheLookup
	WebElement ProfileSubmit;

	@FindBy(xpath = "//div[contains(text(), 'Profile Updated Successfully')]")
	@CacheLookup
	WebElement SubmitConfirmation;

	@FindBy(xpath = "//*[@id=\"principal-menu\"]/li[7]/a[2]")
	@CacheLookup
	WebElement SignOutLink;





	public AccountManagement(WebDriver driver) {

		this.driver = driver;
	}


	public void Join(String fname, String lname, String emailid, String pass, String confirm_pass, String mobile, String phone, String dob) throws InterruptedException {

		SigninLink.click();
		JoinTab.click();
		JoinFirstName.sendKeys(fname);
		JoinLastName.sendKeys(lname);
		JoinEmail.sendKeys(emailid);
		JoinPassword.sendKeys(pass);
		JoinConfirmPassword.sendKeys(confirm_pass);
		JoinOptIn1.click();
		//		JoinOptIn2.click();
		//		ExpandButton.click();
		JoinMobileNumber.sendKeys(mobile);
		JoinPhoneNumber.sendKeys(phone);
		JoinBirthDate.sendKeys(dob);

		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.visibilityOf(JoinContinueBtn)).click();

		EditProfileLink.click();
		Address1.clear();
		Address1.sendKeys("Test Address 1");
		Address2.clear();
		Address2.sendKeys("Test Address 2");
		zip.clear();
		zip.sendKeys("10010");
		ProfileSubmit.click();

		Assert.assertTrue(SubmitConfirmation.getText(), true);
		Assert.assertEquals("Profile Updated Successfully", SubmitConfirmation.getText());
		System.out.println("Test Passed successfully");

		SignOutLink.click();


	}




}
