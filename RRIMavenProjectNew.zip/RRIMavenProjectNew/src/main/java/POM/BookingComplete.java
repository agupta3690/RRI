package POM;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;




public class BookingComplete {

	WebDriver driver;
	
	@FindBy(className = "confirm-code")
	@CacheLookup
	WebElement BookingNumber;
	
	@FindBy(id = "another-reservation")
	@CacheLookup
	WebElement AnotherReservation_btn;

	@FindBy(className = "share-cta share icon icon-share")
	@CacheLookup
	WebElement Share_link;

	@FindBy(className = "modify-cta modify icon icon-modify")
	@CacheLookup
	WebElement Modify_Reservation_link;

	@FindBy(className = "directions-cta directions icon icon-directions")
	@CacheLookup
	WebElement Directions_link;
	
	@FindBy(className = "cancel-cta cancel icon icon-cancel")
	@CacheLookup
	WebElement Cancel_Reservation_link;

	@FindBy(className = "submit-cta module-cta submit-cta")
	@CacheLookup
	WebElement JoinNow_btn;

						
}
