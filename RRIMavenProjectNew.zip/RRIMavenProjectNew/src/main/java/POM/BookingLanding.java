package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class BookingLanding {
	
WebDriver driver;
	
	@FindBy(xpath = "//*[@id=\"LocationTextFrom\"]")
	@CacheLookup
	WebElement location_from;
	
	@FindBy(xpath = "//*[@id=\"LocationTextTo\"]")
	@CacheLookup
	WebElement location_to;
	
	@FindBy(xpath = "//*[@id=\"along-a-route-search\"]")
	@CacheLookup
	WebElement along_a_route_search_btn;
	
	
	public BookingLanding(WebDriver driver) {
		
		this.driver = driver;
	}
	
	
	public void along_a_route_search(String from, String to) {
		
		location_from.clear();
		location_from.sendKeys(from);
		location_to.sendKeys(to);
		along_a_route_search_btn.click();
	}

}
