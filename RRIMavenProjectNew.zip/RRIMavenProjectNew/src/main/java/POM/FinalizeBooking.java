package POM;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;




public class FinalizeBooking {
	
	WebDriver driver;
	
	@FindBy(xpath = "html/body/div[1]/form/div[3]/div/div/label[1]")
	@CacheLookup
	WebElement Checkbox;
	
	@FindBy(xpath = "//*[@id='finalize']")
	@CacheLookup
	WebElement Finalize_btn;
	
	public FinalizeBooking(WebDriver driver) {
		
		this.driver = driver;
	}
	
	public void finalize() {
		
		Checkbox.click();
		Finalize_btn.click();
	}

}
