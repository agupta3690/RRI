package POM;



import org.openqa.selenium.*;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;





public class HomePage {

	
	
	WebDriver driver;
	
	@FindBy(id = "LocationText")
	@CacheLookup
	WebElement location;
	
	@FindBy(id = "checkin")
	@CacheLookup
	WebElement checkin_panel;
	
	@FindBy(xpath = "html/body/div[1]/section[1]/div/section/form/div[3]/div[2]/div/div/div[3]/div/div/div[2]/div/nav[1]/div[3]")
	@CacheLookup
	WebElement calendarForward;

	@FindBy(className = "pmu-month")
	@CacheLookup
	WebElement monthName;
	
	@FindBy(id = "checkout")
	@CacheLookup
	WebElement checkout_panel;

	@FindBy(xpath = "//a[contains(@date, '20180515')]")
	@CacheLookup
	WebElement checkin_date;
	
	@FindBy(xpath = "//a[contains(@date, '20180516')]")
	@CacheLookup
	WebElement checkout_date;

	@FindBy(id = "accomodations")
	@CacheLookup
	WebElement accomodations_panel;
	
	@FindBy(xpath = "//a[@class='module-cta plus']")
	@CacheLookup
	WebElement accomodations_adults_count;
	
	@FindBy(xpath = "(//a[@class='module-cta plus'])[2]")
	@CacheLookup
	WebElement accomodations_kids_count;
	
	@FindBy(xpath = "//label[contains(@for,'room2')]")
	@CacheLookup
	WebElement accomodations_room_count;
	
	@FindBy(xpath = "//input[contains(@value,'Search')]")
	@CacheLookup
	WebElement search_btn;
	
	@FindBy(xpath = "//div[@class='links']/a[1]")
	@CacheLookup
	WebElement along_a_route;
	
	
	public HomePage(WebDriver driver) {
		
		this.driver = driver;
		
	}
	
	public void locationSearch(String loc) {
		
		location.clear();
		location.sendKeys(loc);
		checkin_panel.click();
		checkin_date.click();
		checkout_date.click();
		accomodations_panel.click();
		accomodations_adults_count.click();
		accomodations_kids_count.click();
		accomodations_room_count.click();
		search_btn.click();
		
	}
	
	public void along_a_route() {
		
		along_a_route.click();
	}

	
}




